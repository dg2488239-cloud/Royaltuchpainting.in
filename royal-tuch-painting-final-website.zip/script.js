function sendWhatsApp(e){
  e.preventDefault();
  const n=document.getElementById('name').value.trim();
  const p=document.getElementById('phone').value.trim();
  const l=document.getElementById('location').value.trim();
  const s=document.getElementById('service').value;
  const a=document.getElementById('area').value.trim() || 'Not specified';
  const text=`Hi Royal Tuch Painting,%0A%0AName: ${encodeURIComponent(n)}%0AMobile: ${encodeURIComponent(p)}%0ALocation: ${encodeURIComponent(l)}%0AService: ${encodeURIComponent(s)}%0AArea: ${encodeURIComponent(a)} sq ft%0A%0AI need a free painting quotation.`;
  window.open(`https://wa.me/919035376925?text=${text}`,'_blank');
}
function updateEstimate(){
  const area=Math.max(0,Number(document.getElementById('calcArea').value)||0);
  const rate=Number(document.getElementById('calcType').value)||12;
  document.getElementById('estimate').textContent='₹'+Math.round(area*rate).toLocaleString('en-IN');
}
document.getElementById('calcArea').addEventListener('input',updateEstimate);
document.getElementById('calcType').addEventListener('change',updateEstimate);
updateEstimate();
